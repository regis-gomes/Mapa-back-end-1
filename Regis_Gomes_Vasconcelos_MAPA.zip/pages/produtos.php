<div id="imagemPaginaPrincipal">
	<h1>Confira nossas marmitas</h1>
	<p>Aqui você encontra o nosso cardápio das marmitas</p>
	<div class="imgPequena">
		<div class="imgProduto">
			<img src="images/spagueti.JPG"><br>		
		</div>
		<p class="texto">Spaguetti ao Pesto com Tomates Assados (Vegano)</p>
		<a href="index.php?pg=5&cod=0"> <p class="comprar"> Ver mais</p></a>
		
	</div>

	<div class="imgPequena">
		<div class="imgProduto">
			<img src="images/marmita_saudavel.JPG"><br>
			
		</div>
		<p class="texto">Marmita Saudável</p>
		<a href="index.php?pg=5&cod=1">  <p class="comprar"> Ver mais</p></a>	
		
	</div>

	<div class="imgPequena">
		<div class="imgProduto">
			<img src="images/marmita_caseira.JPG"><br>
		</div>
		<p class="texto">Marmita Caseira</p>
		<a href="index.php?pg=5&cod=2">  <p class="comprar"> Ver mais</p></a>
		
	</div>

	<div class="imgPequena">
		<div class="imgProduto">
			<img src="images/spagueti.JPG"><br>
			
		</div>
		<p class="texto">Spaguetti ao Pesto com Tomates Assados (Vegano)</p>
		<a href="index.php?pg=5&cod=0">  <p class="comprar"> Ver mais</p></a>		
		
	</div>
	

	<div class="imgPequena">
		<div class="imgProduto">
			<img src="images/marmita_saudavel.JPG"><br>
			
		</div>
		<p class="texto">Marmita Saudável</p>
		<a href="index.php?pg=5&cod=1">  <p class="comprar"> Ver mais</p></a>	
		
	</div>

	<div class="imgPequena">
		<div class="imgProduto">
			<img src="images/marmita_caseira.JPG"><br>
		</div>
		<p class="texto">Marmita Caseira</p>
		<a href="index.php?pg=5&cod=2">  <p class="comprar"> Ver mais</p></a>
		
	</div>

	<div class="imgPequena">
		<div class="imgProduto">
			<img src="images/marmita_saudavel.JPG"><br>
			
		</div>
		<p class="texto">Marmita Saudável</p>
		<a href="index.php?pg=5&cod=1">  <p class="comprar"> Ver mais</p></a>	
		
	</div>

	<div class="imgPequena">
		<div class="imgProduto">
			<img src="images/marmita_caseira.JPG"><br>
		</div>
		<p class="texto">Marmita Caseira</p>
		<a href="index.php?pg=5&cod=2">  <p class="comprar"> Ver mais</p></a>
		
	</div>
	
</div>