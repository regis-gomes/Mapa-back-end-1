<div id="imagemPaginaPrincipal">
	<p>INTEGRAIS</p>
	<div class="imgPequena">
		<img src="images/biscoito.JPG">
		
	</div>
	<div class="imgPequena">
		<img src="images/granola.JPG">
		
	</div>
	<div class="imgPequena">
		<img src="images/coco.JPG">
		
	</div>
	<div class="imgPequena">
		<img src="images/barrinha.JPG">
		
	</div>
	<div class="imgPequena">
		<img src="images/pasta.JPG">
		
	</div>
	<div class="imgPequena">
		<img src="images/granola.JPG">
		
	</div>
	<hr>
	<p>DESTAQUE DO MÊS</p>
	<div class="destaque">
		<img src="images/destaque.JPG">
		
	</div>
	<div class="destaque">
		<h1>Doce de coco caseiro</h1>
		<p>
			Modo de fazer
			 <br>Coloque todos os ingredientes em uma panela alta e leve <br>ao fogo mexendo <br>sempre até levantar fervura, diminua a temperatura do fogo e continue<br> mexendo até que forme<br> um creme mais grosso
			 <br>Leva cerca de 10 minutos
			 <br>Apague o fogo e espere esfriar
			 <br>Depois de frio misture o doce de leite
			 <br>Bom Apetite

		</p>
		
	</div>
</div>
<!--https://www.docemalu.com.br/pasta-de-amendoim-integral-power-one-1005kg---nut/p-->